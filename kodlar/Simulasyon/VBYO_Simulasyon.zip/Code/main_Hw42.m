% main code for the Hw 4, Question 2
% 
% Sinan Yildirim, 17.12.2016

clear all; clc; close all; fc = 0;

y = [125, 18, 20, 34];

theta0 = 0.5;
M = 100000;

alpha = 2; beta = 2;

% Gibbs sampling
[Theta_Gibbs, Z] = Gibbs_for_genetic_linkage(y, M, theta0, alpha, beta);

% MH
[Theta_MH] = MH_for_genetic_linkage(y, M, theta0, alpha, beta);

subplot(1, 2, 1);
hist(Theta_Gibbs, 50);
title('histogram of 10000 samples obtained with Gibbs sampling');
subplot(1, 2, 2);
hist(Theta_MH, 50);
title('histogram of 10000 samples obtained with independence MH algorithm');
