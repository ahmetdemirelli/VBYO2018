function [X] = MH_Poiss_chp(y, M, X_0, alpha, beta, prop_type, sigma_q)

% [X] = MH_Poiss_chp(y, M, X_0, alpha, beta, prop_type, sigma_q)
%
% Sinan Yildirim, 10.11.2016

n = length(y);

Tau = zeros(1, M);
Lambda_1 = zeros(1, M);
Lambda_2 = zeros(1, M);

tau = X_0(1);
lambda_1 = X_0(2);
lambda_2 = X_0(3);

for m = 1:M
    if prop_type == 1 % symmetric random walk MH
        tau_prop = tau + (-1)^(rand<0.5);
        lambda_1_prop = lambda_1 + randn*sigma_q;
        lambda_2_prop = lambda_2 + randn*sigma_q;
        
        if tau >= 1 && tau <= n && lambda_1_prop > 0 && lambda_2_prop > 0
            
            log_r_0 = -(tau + beta)*(lambda_1_prop - lambda_1) ...
                - (n - tau + beta)*(lambda_2_prop - lambda_2)...
                + (alpha - 1 + sum(y(1:tau)))*(log(lambda_1_prop) - log(lambda_1))...
                + (alpha - 1 + sum(y(tau+1:n)))*(log(lambda_2_prop) - log(lambda_2));
            
            if tau_prop == tau + 1
                log_r = log_r_0 + (lambda_2_prop - lambda_1_prop)...
                    + y(tau+1)*(log(lambda_1_prop) - log(lambda_2_prop));
            elseif tau_prop == tau - 1
                log_r = log_r_0 + (lambda_1_prop - lambda_2_prop)...
                    + y(tau)*(log(lambda_2_prop) - log(lambda_1_prop));
            end
            
        else
            log_r = -inf;
        end
        
    elseif prop_type == 2 % independence random walk MH
        tau_prop = ceil(n*rand);
        lambda_1_prop = gamrnd(alpha, beta);
        lambda_2_prop = gamrnd(alpha, beta);
        
        log_lkl_prop = -(lambda_1_prop*tau_prop + lambda_2_prop*(n-tau_prop))...
            + log(lambda_1_prop)*sum(y(1:tau_prop))...
            + log(lambda_2_prop)*sum(y(tau_prop+1:n));
        log_lkl_curr = -(lambda_1*tau + lambda_2*(n-tau))...
            + log(lambda_1)*sum(y(1:tau))...
            + log(lambda_2)*sum(y(tau+1:n));
        
        log_r = log_lkl_prop - log_lkl_curr;
    end
    
    % decision to accept or reject
    decision = rand < exp(log_r);
    % new value for the chain
    tau = decision*tau_prop + (1 - decision)*tau;
    lambda_1 = decision*lambda_1_prop + (1 - decision)*lambda_1;
    lambda_2 = decision*lambda_2_prop + (1 - decision)*lambda_2;
    
    Tau(m) = tau;
    Lambda_1(m) = lambda_1;
    Lambda_2(m) = lambda_2;
    
    
end

X = [Tau; Lambda_1; Lambda_2];