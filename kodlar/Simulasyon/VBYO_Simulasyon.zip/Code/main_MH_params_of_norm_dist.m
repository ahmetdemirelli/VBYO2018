% main code for MH for posterior distribution of the unknown mean and the
% variance of the normal distribution
% 
% Sinan Yildiri, 10.11.2016

clear all; clc; close all; fc = 0;


% mean and variance
z = 3; s = 10;

% generate data
n = 100;
y = randn(1, 100)*sqrt(s) + z;

%% MH algorithm:
M = 100000;

% prior distribution parameters for the mean
mu = 0; kappa = 10;

% prior distribution parameters for the variance 
alpha = 5; beta = 10;

% parameters for the posterior distribution
sigma_q = 1;
% initial values
z0 = 2; s0 = 10;
z = z0;
s = s0;
S = zeros(1, M);
Z = zeros(1, M);
for m = 1:M
    % propose z and s
    z_prop = z + randn*sigma_q;
    s_prop = 1/gamrnd(alpha, 1/beta);
    
    % log acceptance ratio
    log_pz_ratio = -((z_prop - mu)^2 - (z - mu)^2)/(2*kappa^2);
    log_lkl_ratio = -0.5*(sum((y - z_prop).^2)/s_prop + n*log(2*pi*s_prop))...
        +0.5*(sum((y - z).^2)/s + n*log(2*pi*s));
    
    log_r = log_pz_ratio + log_lkl_ratio;
    
    % decision to accept or reject
    decision = rand < exp(log_r);
    
    s = decision*s_prop + (1 - decision)*s;
    z = decision*z_prop + (1 - decision)*z;
    
    % store the values
    S(m) = s;
    Z(m) = z;
end

subplot(1, 3, 1);
plot(Z);
xlabel('iteration');
ylabel('Z_{t}');
title('marginal posterior for z');
subplot(1, 3, 2);
plot(S);
ylabel('S_{t}');
xlabel('iteration');
title('marginal posterior for s');
subplot(1, 3, 3);
scatter(Z, S);
xlabel('Z_{t}'); ylabel('S_{t}');
title('joint posterior');
