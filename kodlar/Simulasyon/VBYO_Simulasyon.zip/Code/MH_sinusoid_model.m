function [X] = MH_sinusoid_model(y, M, X0, var_a, alpha, beta, ...
    sigma_q_a, sigma_q_w, sigma_q_z, sigma_q_var_y)

% [X] = MH_sinusoid_model(y, M, X0, var_a, alpha, beta, sigma_q_a, ...
%    sigma_q_w, sigma_q_var_y)
% 
% MH algorithm for the sinusoid model
% 
% Sinan Yildirim, 17.12.2016

n = length(y);

a = X0(1);
w = X0(2);
z = X0(3);
var_y = X0(4);

A = zeros(1, M);
W = zeros(1, M);
Z = zeros(1, M);
Var_y = zeros(1, M);

for m = 1:M
    % propose the new value (check thay q(x' | x) = q(x | x')):
    a_prop = a + randn*sigma_q_a;
    w_prop = w + randn*sigma_q_w;
    z_prop = z + randn*sigma_q_z;
    var_y_prop = var_y + randn*sigma_q_var_y;
    
    if w_prop > 0 && var_y_prop > 0 && z_prop < 2*pi && z_prop > 0
        % otherwise reject and keep the previous sample
        
        % calculate the log acceptance ratio
        log_prior_ratio = -0.5*(a_prop^2 - a^2)/var_a...
            + (alpha - 1)*(log(w_prop) - log(w)) - beta*(w_prop - w)...
             -(alpha+1)*(log(var_y_prop) - log(var_y)) ...
             - (1/beta)*(1/var_y_prop - 1/var_y);
        
         log_lkl_ratio = -n*0.5*(log(var_y_prop) - log(var_y)) ...
            - 0.5*sum((y - a_prop*sin(w_prop*(1:n) + z_prop)).^2/var_y_prop ...
            - (y - a*sin(w*(1:n) + z)).^2/var_y);
        
        log_r = log_prior_ratio + log_lkl_ratio;
        
        % accept-reject
        decision = rand < exp(log_r);
        a = decision*a_prop + (1 - decision)*a;
        w = decision*w_prop + (1 - decision)*w;
        z = decision*z_prop + (1 - decision)*z;
        var_y = decision*var_y_prop + (1 - decision)*var_y;
        
    end
    A(m) = a;
    W(m) = w;
    Z(m) = z;
    Var_y(m) = var_y;
end

X = [A; W; Z; Var_y];
