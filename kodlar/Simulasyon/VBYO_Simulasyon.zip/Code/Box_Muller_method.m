function [X] = Box_Muller_method(mu, sigma, N)

% [X] = Box_Muller_method(mu, sigma, N)
% 
% Box Muller method to generate N normal random variables with mean mu
% and variance sigma^2
% 
% Sinan Yildirim, 08.11.2016

X = zeros(1, ceil(N/2)*2);

n = 0;
while n < N
    % generate U_{1}, U_{2} ~ Unif(0, 1)
    U = rand(2, 1);
    X(n+1:n+2) = sqrt(-2*log(U(1)))*[cos(2*pi*U(2)) sin(2*pi*U(2))];
    n = n + 2;
end

% Truncate X if N is odd and hence one too many samples were generated
if mod(N, 2) == 1
    X = X(1:N);
end

% Finally, shift and scale X
X = sigma*X + mu;