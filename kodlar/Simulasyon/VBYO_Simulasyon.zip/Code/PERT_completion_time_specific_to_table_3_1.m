function [E] = PERT_completion_time_specific_to_table_3_1(T)

% [E] = PERT_completion_time_specific_to_table_3_1(T)
% 
% This function calculates the completion time for the PERT example whose
% predecessor structure is given in Table 3.1. Each row corresponds to an 
% independent experiment.
% 
% Sinan Yildirim, 08.11.2016

E_1 = T(:, 1);
S_2 = E_1; E_2 = S_2 + T(:, 2);

S_3 = E_1; E_3 = S_3 + T(:, 3);

S_4 = E_2; E_4 = S_4 + T(:, 4);
S_5 = E_2; E_5 = S_5 + T(:, 5);

S_6 = E_3; E_6 = S_6 + T(:, 6);
S_7 = E_3; E_7 = S_7 + T(:, 7);
S_8 = E_3; E_8 = S_8 + T(:, 8);

S_9 = max([E_5 E_6 E_7], [], 2); E_9 = S_9 + T(:, 9);
S_10 = max([E_4 E_8 E_9], [], 2); E_10 = S_10 + T(:, 10);

E = E_10;