function [Theta] = MH_for_genetic_linkage(y, M, theta0, alpha, beta)

% [Theta] = MH_for_genetic_linkage(y, M, theta0)
% 
% This function uses independence MH algorithm for the genetic linkage
% problem.
%
% Sinan Yildirim, 17.12.2016

Theta = zeros(1, M);

theta = theta0;

for m = 1:M
    
    % sample theta_prop independently from the uniform distribution
    theta_prop = rand;

    log_r = y(1)*log(1/2 + theta_prop/4) ...
        + (y(2) + y(3))*log((1 - theta_prop)/4)...
        + y(4)*log(theta_prop/4) + (alpha - 1)*log(theta_prop) ...
        + (beta - 1)*log(1 - theta_prop)...
        -(y(1)*log(1/2 + theta/4) ...
        + (y(2) + y(3))*log((1 - theta)/4)...
        + y(4)*log(theta/4) + (alpha - 1)*log(theta) ...
        + (beta - 1)*log(1 - theta));
    
    % accept-reject decision
    decision = rand < exp(log_r);
    
    theta = decision*theta_prop + (1 - decision)*theta;
    Theta(m) = theta;
end
    