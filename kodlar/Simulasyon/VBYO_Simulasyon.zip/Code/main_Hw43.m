% main code for the Hw 4, Question 3
% 
% Gibbs sampling for the mean and the variance of the normal distribution
% 
% Sinan Yildirim, 17.12.2016

clear all; clc; close all; fc = 0;


% true values
z = 3;
s = 2;

m = 0;
kappa = 10;
alpha = 5; beta = 10;

n = 100;

y = randn(1, n)*sqrt(s) + z;

% Gibbs sampler for z and s
T = 10000;
Z = zeros(1, T);
S = zeros(1, T);

% initial value:
s = 1;

for t = 1:T
    % sample z given s and y_1:n
    cond_var = (1/kappa^2 + n/s)^(-1);
    cond_mean = cond_var*(sum(y)/s + m/kappa^2);
    z = sqrt(cond_var)*randn + cond_mean;
    
    alpha_cond = alpha + n/2;
    beta_cond = beta + 0.5*sum((y - z).^2);
    s = 1/gamrnd(alpha_cond, 1/beta_cond);
    
    Z(t) = z;
    S(t) = s;
end

% scatter plot of the samples
scatter(Z, S);
xlabel('z'); ylabel('s');
title('samples from Gibbs sampling');

    