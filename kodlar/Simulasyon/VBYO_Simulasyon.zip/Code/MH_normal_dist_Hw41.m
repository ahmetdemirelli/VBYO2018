function [X, a_vec] = MH_normal_dist_Hw41(mu_x, var_x, M, x_0, prop_params, prop_type)

% [X, a_vec] = MH_normal_dist_Hw41(mu_x, var_x, M, x_0, prop_params, prop_type)
%
% This function runs the MH algorithm for M iterations for approximately
% sampling from the normal distribution with mean mu_x and variance var_x.
% The initial point is X_0
%
% There are three choices for the proposal type, namely
% symmetric random walk MH, independence MH, and gradient-guided MH, which
% correspond to choices 1, 2, and 3 for prop_type, respectively.
%
% prop_params contains the relevant parameters for the proposal
%
% Sinan Yildirim, 10.11.2016

X = zeros(1, M);
x = x_0;

%initialise the vectro for acceptance probabilities
a_vec = zeros(1, M);


% get the necessary parameters
if prop_type == 1
    sigma_q = prop_params.sigma_q;
elseif prop_type == 2
    mu_q = prop_params.mu_q;
    sigma_q = prop_params.sigma_q;
elseif prop_type == 3
    gamma = prop_params.gamma;
    sigma_q = prop_params.sigma_q;
end

for m = 1:M
    if prop_type == 1 % symmetric random walk MH
        % propose the new value
        x_prop = x + sigma_q*randn;
        % calculate the log acceptance ratio:
        log_r = -((x_prop - mu_x)^2 - (x - mu_x)^2)/(2*var_x);
    elseif prop_type == 2 % independence random walk MH
        % propose the new value
        x_prop = randn*sigma_q + mu_q;
        
        % calculate the log acceptance ratio:
        log_pi_ratio = -((x_prop - mu_x)^2 - (x - mu_x)^2)/(2*var_x);
        log_q_ratio = -((x_prop - mu_q)^2 - (x - mu_q)^2)/(2*sigma_q^2);
        log_r = log_pi_ratio - log_q_ratio;
    elseif prop_type == 3 % gradient-guided proposal
        % propsose the new value
        grad_x = -(x - mu_x)/var_x;
        g_x = x + gamma*grad_x;
        x_prop = g_x + randn*sigma_q;
        
        % calculate the log acceptance ratio:
        g_x_prop = x_prop - gamma*(x_prop - mu_x)/var_x;
        
        log_pi_ratio = -((x_prop - mu_x)^2 - (x - mu_x)^2)/(2*var_x);
        log_q_ratio = -((x_prop - g_x)^2 - (x - g_x_prop)^2)/(2*sigma_q^2);
        log_r = log_pi_ratio - log_q_ratio;
    end
    
    % decision to accept or reject
    decision = rand < exp(log_r);
    % new value for the chain
    x = decision*x_prop + (1 - decision)*x;
    
    % store x
    X(m) = x;
    % store the acceptance probability
    a_vec(m) = min(1, exp(log_r));
end