% The sinusoid with unknown amplitude constant
% 
% This is the code for the 4'th part of Hw3.
% 
% Sinan Yildirim, 28.11.2016

clear all; clc; close all;

n = 100;
T = 40;
var_x = 100;
var_y = 10;

% generate data:
x = sqrt(var_x)*randn;
t = 1:n;
y = x*sin(2*t*pi/T) + randn(1, n)*sqrt(var_y);


% calculate  p(x|y1:n), p(yn+1) and p(yn+1|y1:n)

% p(x|y1:n)
S_xy = 1/(1/var_x + sum(sin(2*t*pi/T).^2)/var_y);
m_xy = S_xy*sum(sin(2*t*pi/T).*y)/var_y;

% p(yn+1)
mu_y_marg = 0;
var_y_marg = sin(2*pi*(n+1)/T)^2*var_x + var_y;

% p(yn+1|y1:n)
mu_y_pred = sin(2*pi*(n+1)/T)*m_xy;
var_y_pred = sin(2*pi*(n+1)/T)^2*S_xy + var_y;


fprintf('Posterior mean and variance for x are %.3f and %.3f \n', m_xy, S_xy);
% plot the densities for y_n+1 on the same axis:
axis_vec = -100:0.001:100;
pdf_post = normpdf(axis_vec, m_xy, S_xy);
pdf_y_marg = normpdf(axis_vec, mu_y_marg, var_y_marg);
pdf_y_pred = normpdf(axis_vec, mu_y_pred, var_y_pred);

plot(axis_vec, pdf_y_marg, 'r');
hold on;
plot(axis_vec, pdf_y_pred, 'k');
hold off;
xlabel('y_{n+1}');
ylabel('densities');
legend('p(y_{n+1})', 'p(y_{n+1} | y_{1:n})');

