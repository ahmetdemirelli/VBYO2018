% main code for the Hw 4, Question 4
% 
% Gibbs sampling for the mean and the variance of the normal distribution
% 
% Sinan Yildirim, 17.12.2016

clear all; clc; close all; fc = 0;

load('UK_coal_mining_disaster_days');

n = 112;
year_lengths = 365*ones(1, n);
% starting from 1852, which is the second year, every fourth year a leap
% year
year_lengths(2:4:end) = 366;
% finally, 1900 is not a leap year, since it is divisible by 100 but not by
% 400. (check the rules on the web!)
year_lengths(50) = 365;

% calculate the cumulative sum to obtaine the intervals
cumsum_year_lengths = [0 cumsum(year_lengths)];

y = zeros(1, n);
for i = 1:n
    y(i) = sum((Y <= cumsum_year_lengths(i+1)) & (Y > cumsum_year_lengths(i)));
end

%% MCMC
M = 100000;

% prior parameters
alpha = 10; beta = 1;

X_0 = [floor(n/2), mean(y), mean(y)];

% MH algorithm
% Symmetric proposal
prop_type = 1;
sigma_q = 1;

[X_MH] = MH_Poiss_chp(y, M, X_0, alpha, beta, prop_type, sigma_q);

% Gibbs sampling
[X_Gibbs] = Gibbs_Poiss_chp(y, M, X_0, alpha, beta);

fc = fc + 1; figure(fc);
t_b = 10000;
subplot(2, 3, 1);
hist(X_MH(1, t_b:end), 20:60);
set(gca, 'xlim', [20, 60]);
title('MH samples from \tau');
subplot(2, 3, 2);
hist(X_MH(2, t_b:end), 50);
title('MH samples from \lambda_{1}');
subplot(2, 3, 3);
hist(X_MH(3, t_b:end), 50);
title('MH samples from \lambda_{2}');
subplot(2, 3, 4);
hist(X_Gibbs(1, t_b:end), 20:60);
set(gca, 'xlim', [20, 60]);
title('Gibbs sampling samples from \tau');
subplot(2, 3, 5);
hist(X_Gibbs(2, t_b:end), 50);
title('Gibbs sampling samples from \lambda_{1}');
subplot(2, 3, 6);
hist(X_Gibbs(3, t_b:end), 50);
title('Gibbs sampling samples from \lambda_{2}');
