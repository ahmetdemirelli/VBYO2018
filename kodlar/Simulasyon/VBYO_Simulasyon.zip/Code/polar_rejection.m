function [X] = polar_rejection(mu, sigma, N)

% [X] = polar_rejection(mu, sigma, N)
% 
% Polar rejection method to generate N normal random variables with mean mu
% and variance sigma^2
% 
% Sinan Yildirim, 08.11.2016

X = zeros(1, ceil(N/2)*2);

n = 0;
while n < N
    % generate V_{1}, V_{2} ~ Unif(-1, 1)
    V = 2*(rand(2, 1)-0.5);
    
    % check for the condition
    T = V(1)^2 + V(2)^2;
    if T < 1
        % generate two independent normal random variables
        X(n+1:n+2) = V*sqrt(-2*log(T)/T);
        n = n + 2;
    end
end

% Truncate X if N is odd and hence one too many samples were generated
if mod(N, 2) == 1
    X = X(1:N);
end

% Finally, shift and scale X
X = sigma*X + mu;