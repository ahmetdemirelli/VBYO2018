% main code for the Hw 4, Question 5
% 
% Gibbs sampling for the mean and the variance of the normal distribution
% 
% Sinan Yildirim, 17.12.2016

clear all; clc; close all; fc = 0;

load('sinusoid_data');

var_a = 100; alpha = 0.1; beta = 0.1;

% initial point
a0 = 5; w0 = 0.1; z0 = pi/2; var_y0 = 5; 
X0 = [a0, w0, z0, var_y0];

sigma_q_a = 0.05; sigma_q_w = 0.002; sigma_q_var_y = 0.02; sigma_q_z = 0.2;
M = 100000;
%% MH
[X] = MH_sinusoid_model(y, M, X0, var_a, alpha, beta, sigma_q_a, ...
    sigma_q_w, sigma_q_z, sigma_q_var_y);

fc = fc + 1; figure(fc);
subplot(2, 2, 1);
plot(X(1, :));
title('MH samples for a');
subplot(2, 2, 2);
plot(X(2, :));
title('MH samples for w');
subplot(2, 2, 3);
plot(X(3, :));
title('MH samples for z');
subplot(2, 2, 4);
plot(X(4, :));
title('MH samples for \sigma_{y}^{2}');

%% MH within Gibbs
[X] = MH_within_Gibbs_sinusoid_model(y, M, X0, var_a, alpha, beta, ...
    sigma_q_w, sigma_q_z, sigma_q_var_y);

fc = fc + 1; figure(fc);
subplot(2, 2, 1);
plot(X(1, :));
title('Gibbs sampling samples for a');
subplot(2, 2, 2);
plot(X(2, :));
title('Gibbs sampling samples for w');
subplot(2, 2, 3);
plot(X(3, :));
title('Gibbs sampling samples for z');
subplot(2, 2, 4);
plot(X(4, :));
title('Gibbs sampling samples for \sigma_{y}^{2}');
