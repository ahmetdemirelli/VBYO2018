% This code is used to generate the plots for SIS vs SISR comparison.
% 
% Sinan Yildirim, 18.10.2016
% 

clear all; close all; clc; fc = 0;

% parameters
a = 0.99; b = 1; var_x = 1; var_y = 1; var_x0 = 4;

% Generate the observations
n = 10;
X = zeros(1, n);
X(1) = 0;
for t = 2:n
    X(t) = a*X(t-1) + randn*sqrt(var_x);
end
Y = b*X + randn(1, n)*sqrt(var_y);

%% SIS

% number of samples
N = 10;

X_Par = zeros(n, N);
log_W_Par = ones(n, N);
W_Par_norm= ones(n, N);


% initialise

for t = 1:n
    % propagate the paths
    if t == 1
        % generate N samples for X(1) from the importance density
        X_samples = sqrt(var_x0)*randn(1, N);
        % weight the particles
        log_w_samples = -(Y(1) - b*X_samples).^2/(2*var_y) - 0.5*log(2*pi*var_y);
        log_W_Par(1, :) = log_w_samples;
        
    else
        % extend N samples using the importance density
        X_samples = a*X_samples + sqrt(var_x)*randn(1, N);
        % calculate the incremental weights
        log_w_inc = -(Y(t) - b*X_samples).^2/(2*var_y) - 0.5*log(2*pi*var_y);
        % update the weights:
        log_W_Par(t, :) = log_W_Par(t-1, :) + log_w_inc;
    end
    
    % store the samples
    X_Par(t, :) = X_samples;
    
    % normalise the weights
    W_Par_norm(t, :) = exp(log_W_Par(t, :) - log_sum(log_W_Par(t, :)));
    
    
end

%% Plot the results for SIS
min_X = min(X_Par(:));
max_X = max(X_Par(:));


R = 1000;
x_axis = linspace(min(min_X-0.5, min(Y)-2), max(max_X +0.5, max(Y)+2), R);
y_lims = [min(min_X-0.5, min(Y)-2), max(max_X +0.5, max(Y)+2)];

for t = 1:n
    % visualise the particles at time t - before weighting
    fc = fc + 1;
    figure(fc);
    if t == 1
        plot(repmat((1:t)', 1, N), X_Par(1:t, :), '*', 'markersize', 5);
    else
        plot(repmat((1:t)', 1, N), X_Par(1:t, :), '*-', 'markersize', 5);
    end
    
    hold on;
    if t == 1
        for j = 1:N
            plot(1, X_Par(t, j), 'ko', 'markersize', 2*(100/N)^0.5, ...
                'markerfacecolor', 'b');
        end
    else
        for j = 1:N
            plot(t, X_Par(t, j), 'ko', 'markersize', 2*(100*W_Par_norm(t-1, j))^0.5, ...
                'markerfacecolor', 'b');
        end
    end
    
    hold on;
    log_w_inc = -(Y(t) - b*x_axis).^2/(2*var_y) - 0.5*log(2*pi*var_y);
    w_inc = exp(log_w_inc - log_sum(log_w_inc));
    w_inc = w_inc/max(w_inc);
    
    plot(t*ones(1, R)+w_inc, x_axis, 'r');
    hold off;
    xlabel('time step'); ylabel('sample values');
    title(sprintf('Sequential importance sampling - before weighting: t = %d', t));
    set(gca, 'xlim', [0, n+1], 'ylim', y_lims);
    saveas(gca, sprintf('SIS_t_%d', t), 'epsc');
    
    saveas(gca, sprintf('SIS_pred_t_%d', t), 'epsc');
    
    % visualise the particles at time t - after weighting
    fc = fc + 1;
    figure(fc);
    if t == 1
        plot(repmat((1:t)', 1, N), X_Par(1:t, :), '*', 'markersize', 5);
    else
        plot(repmat((1:t)', 1, N), X_Par(1:t, :), '*-', 'markersize', 5);
    end
    
    for i = t:t
        for j = 1:N
            hold on;
            plot(i, X_Par(i, j), 'ko', 'markersize', 2*(100*W_Par_norm(i, j))^0.5, ...
                'markerfacecolor', 'b');
        end
    end
    hold on;
    log_w_inc = -(Y(t) - b*x_axis).^2/(2*var_y) - 0.5*log(2*pi*var_y);
    w_inc = exp(log_w_inc - log_sum(log_w_inc));
    w_inc = w_inc/max(w_inc);
    
    plot(t*ones(1, R)+w_inc, x_axis, 'r');
    hold off;
    xlabel('time step'); ylabel('sample values');
    title(sprintf('Sequential importance sampling - after weighting, t = %d', t));
    set(gca, 'xlim', [0, n+1], 'ylim', y_lims);
    saveas(gca, sprintf('SIS_t_%d', t), 'epsc');
end


%% SISR
log_W_Par = ones(n, N);
W_Par_norm= ones(n, N);

X_Par = cell(1, N);

% initialise

for t = 1:n
    % propagate the paths
    X_Par{t} = zeros(t, N);
    if t == 1
        % generate N samples for X(1) from the importance density
        X_samples = sqrt(var_x0)*randn(1, N);
        % weight the particles
        log_w_samples = -(Y(1) - b*X_samples).^2/(2*var_y) - 0.5*log(2*pi*var_y);
        log_W_Par(1, :) = log_w_samples;
        
    else
        % resample:
        [res_ind] = resample(W_Par_norm(t-1, :), 'multinomial');
        X_samples = X_samples(res_ind);
        X_Par{t}(1:t-1, :) = X_Par{t-1}(:, res_ind);
        
        % extend N samples using the importance density
        X_samples = a*X_samples + sqrt(var_x)*randn(1, N);
        % calculate the incremental weights
        log_w_inc = -(Y(t) - b*X_samples).^2/(2*var_y) - 0.5*log(2*pi*var_y);
        % update the weights:
        log_W_Par(t, :) = log_w_inc;
    end
    
    % store the samples
    X_Par{t}(t, :) = X_samples;
    
    % normalise the weights
    W_Par_norm(t, :) = exp(log_W_Par(t, :) - log_sum(log_W_Par(t, :)));
    
    
end


%% Plot the results for SISR

% find the minimum of all generated samples to set the limit for the axes
% and the plots
minx = zeros(1, n);
maxx = zeros(1, n);
for t = 1:n
    minx(t) = min(X_Par{t}(:));
    maxx(t) = max(X_Par{t}(:)); 
end
min_X = min(minx);
max_X = max(maxx);
R = 1000;
x_axis = linspace(min(min_X-0.5, min(Y)-2), max(max_X +0.5, max(Y)+2), R);
y_lims = [min(min_X-0.5, min(Y)-2), max(max_X +0.5, max(Y)+2)];


for t = 1:n
    
    % visualise the particles at time t - before weighting
    fc = fc + 1;
    figure(fc);
    if t == 1
        plot(repmat((1:t)', 1, N), X_Par{t}(1:t, :), '*', 'markersize', 5);
    else
        plot(repmat((1:t)', 1, N), X_Par{t}(1:t, :), '*-', 'markersize', 5);
    end
    
    hold on;
    for j = 1:N
        plot(t, X_Par{t}(t, j), 'ko', 'markersize', 2*(100/N)^0.5, ...
            'markerfacecolor', 'b');
    end
    
    hold on;
    log_w_inc = -(Y(t) - b*x_axis).^2/(2*var_y) - 0.5*log(2*pi*var_y);
    w_inc = exp(log_w_inc - log_sum(log_w_inc));
    w_inc = w_inc/max(w_inc);
    
    plot(t*ones(1, R)+w_inc, x_axis, 'r');
    hold off;
    xlabel('time step'); ylabel('sample values');
    title(sprintf('Sequential importance sampling - resampling, before weighting t = %d', t));
    set(gca, 'xlim', [0, n+1], 'ylim', y_lims);
    saveas(gca, sprintf('SISR_pred_t_%d', t), 'epsc');
    
    % visualise the particles at time t - after weighting    
    fc = fc + 1;
    figure(fc);
    if t == 1
        plot(repmat((1:t)', 1, N), X_Par{t}(1:t, :), '*', 'markersize', 5);
    else
        plot(repmat((1:t)', 1, N), X_Par{t}(1:t, :), '*-', 'markersize', 5);
    end
    
    for j = 1:N
        hold on;
        plot(t, X_Par{t}(t, j), 'ko', 'markersize', 2*(100*W_Par_norm(t, j))^0.5, ...
            'markerfacecolor', 'b');
    end
    
    hold on;
    log_w_inc = -(Y(t) - b*x_axis).^2/(2*var_y) - 0.5*log(2*pi*var_y);
    w_inc = exp(log_w_inc - log_sum(log_w_inc));
    w_inc = w_inc/max(w_inc);
    
    plot(t*ones(1, R)+w_inc, x_axis, 'r');
    hold off;
    xlabel('time step'); ylabel('sample values');
    title(sprintf('Sequential importance sampling - resampling, after weighting t = %d', t));
    set(gca, 'xlim', [0, n+1], 'ylim', y_lims); 
    saveas(gca, sprintf('SISR_t_%d', t), 'epsc');
end
