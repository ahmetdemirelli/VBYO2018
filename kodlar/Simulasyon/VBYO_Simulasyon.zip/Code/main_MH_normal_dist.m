% main code for the MH algorithms for normal distribution
% 
% Sinan Yildirim, 10.11.2016

clear all; clc; close all; fc = 0;

% number of iterations
M = 50000;

mu_x = 2; var_x = 1;

% initial point
x_0 = 10;

%% random walk MH
prop_type = 1;
sigma_q = 0.1;
prop_params.sigma_q = sigma_q;
[X_1] = MH_normal_dist(mu_x, var_x, M, x_0, prop_params, prop_type);

fc = fc + 1; figure(fc);
subplot(2, 3, 1);
plot(X_1(1:1000));
title('RWMH - first 1000 samples: \sigma_q^2 = 0.01');
xlabel('iterations');
subplot(2, 3, 4);
hist(X_1(10001:end), 50);
title('histogram of last 10000 samples: \sigma_q^2 = 0.01');
xlabel('x');

sigma_q = 20;
prop_params.sigma_q = sigma_q;
[X_2] = MH_normal_dist(mu_x, var_x, M, x_0, prop_params, prop_type);
subplot(2, 3, 2);
plot(X_2(1:1000));
title('RWMH - first 1000 samples: \sigma_q^2 = 400');
xlabel('iterations');
subplot(2, 3, 5);
hist(X_2(10001:end), 50);
title('histogram of last 10000 samples: \sigma_q^2 = 400');
xlabel('x');

sigma_q = sqrt(2);
prop_params.sigma_q = sigma_q;
[X_3] = MH_normal_dist(mu_x, var_x, M, x_0, prop_params, prop_type);
subplot(2, 3, 3);
plot(X_3(1:1000));
title('RWMH - first 1000 samples: \sigma_q^2 = 2');
xlabel('iterations');
subplot(2, 3, 6);
hist(X_3(10001:end), 50);
title('histogram of last 10000 samples: \sigma_q^2 = 2');
xlabel('x');

%% independence MH
prop_params.mu_q = mu_x;
prop_type = 2;

prop_params.sigma_q = sqrt(0.8);
[X_1] = MH_normal_dist(mu_x, var_x, M, x_0, prop_params, prop_type);

fc = fc + 1; figure(fc);
subplot(2, 2, 1);
plot(X_1(1:1000));
title('IMH - first 1000 samples: \sigma_q^2 = 0.8');
xlabel('iterations');
subplot(2, 2, 3);
hist(X_1(10001:end), 50);
title('histogram of last 10000 samples: \sigma_q^2 = 0.8');
xlabel('x');

prop_params.sigma_q = 10;
[X_2] = MH_normal_dist(mu_x, var_x, M, x_0, prop_params, prop_type);
subplot(2, 2, 2);
plot(X_2(1:1000));
title('IMH - first 1000 samples: \sigma_q^2 = 100');
xlabel('iterations');
subplot(2, 2, 4);
hist(X_2(10001:end), 50);
title('histogram of last 10000 samples: \sigma_q^2 = 100');
xlabel('x');


%% grad-guided MH
prop_params.sigma_q = 1;
prop_type = 3;

prop_params.gamma = 0.01;
[X_1] = MH_normal_dist(mu_x, var_x, M, x_0, prop_params, prop_type);

fc = fc + 1; figure(fc);
subplot(2, 2, 1);
plot(X_1(1:1000));
title('grad-MH - first 1000 samples: \gamma = 0.01');
xlabel('iterations');
subplot(2, 2, 3);
hist(X_1(10001:end), 50);
title('histogram of last 10000 samples: \gamma = 0.01');
xlabel('x');

prop_params.gamma = 1;
[X_2] = MH_normal_dist(mu_x, var_x, M, x_0, prop_params, prop_type);
subplot(2, 2, 2);
plot(X_2(1:1000));
title('grad-MH - first 1000 samples: \gamma = 1');
xlabel('iterations');
subplot(2, 2, 4);
hist(X_2(10001:end), 50);
title('histogram of last 10000 samples: \gamma = 1');
xlabel('x');
