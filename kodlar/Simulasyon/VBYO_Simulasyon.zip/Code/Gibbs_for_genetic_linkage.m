function [Theta, Z] = Gibbs_for_genetic_linkage(y, M, theta0, alpha, beta)

% [Theta, Z] = Gibbs_for_genetic_linkage(y, M, theta0, alpha, beta)
% 
% This function runs the Gibbs sampler for the genetic linkage problem for
% M iterations given the data, which is a vector of number of animals in 4
% different categories.
% 
% Sinan Yildirim, 17.12.2016


Theta = zeros(1, M);
Z = zeros(1, M);

theta = theta0;

for m = 1:M
    z = sum(rand(1, y(1)) < theta/(2 + theta));
    theta = betarnd(z + y(4) + alpha, y(2) + y(3) + beta);
    
    Theta(m) = theta;
    Z(m) = z;
end
    