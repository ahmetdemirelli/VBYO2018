% main code for the Hw 4, Question 1
% 
% Sinan Yildirim, 17.12.2016

clear all; clc; close all; fc = 0;

mu_x = 0; var_x = 1;

% initial point
x_0 = 10;

%% random walk MH
prop_type = 1;
sigma_q = 1;
prop_params.sigma_q = sigma_q;
% number of iterations
T = 10000;
% burn in time
t_b = 1000;

% Number of Monte Carlo runs
M = 100;
mean_X_vec = zeros(1, M);
mean_a_vec = zeros(1, M);

for m = 1:M
    [X_1, a_vec] = MH_normal_dist_Hw41(mu_x, var_x, T, x_0, prop_params, prop_type);
    mean_X_vec(m) = mean(X_1(t_b+1:end));
    mean_a_vec(m) = mean(a_vec(t_b+1:end));
end
fprintf('The sample variance of the mean estimates is %.5f \n', var(mean_X_vec));
fprintf('The average of acceptance probability estimates is %.4f \n', mean(mean_a_vec));


%% last part
sigma_q_vec = 0.1:0.1:10;
L_q = length(sigma_q_vec);

Var_mean_X = zeros(1, L_q);
Mean_mean_a = zeros(1, L_q);

for i = 1:L_q
    mean_X_vec = zeros(1, M);
    mean_a_vec = zeros(1, M);
    prop_params.sigma_q = sigma_q_vec(i);

    for m = 1:M
        [X_1, a_vec] = MH_normal_dist_Hw41(mu_x, var_x, T, x_0, prop_params, prop_type);
        mean_X_vec(m) = mean(X_1(t_b+1:end));
        mean_a_vec(m) = mean(a_vec(t_b+1:end));
    end
    Var_mean_X(i) = var(mean_X_vec);
    Mean_mean_a(i) = mean(mean_a_vec);
end

fc = fc + 1; figure(fc);
subplot(2, 1, 1);
plot(sigma_q_vec, Var_mean_X);
title('variance of the mean estimate vs proposal std');
xlabel('\sigma_{q}');
subplot(2, 1, 2);
plot(sigma_q_vec, Mean_mean_a);
title('mean of the acceptance probability estimate vs proposal std');
xlabel('\sigma_{q}');

[a, b] = min(Var_mean_X);
fprintf('The (approximately) optimum std is %.3f \n', sigma_q_vec(b));
fprintf('The (approximately) optimum acceptance probability is %.3f \n', Mean_mean_a(b));