function [E] = PERT_completion_time(T, Predecessor_info)

% [E] = PERT_completion_time(T, Predecessor_info)
% 
% This function computes the completion time of a project given the order
% of the tasks in the Predecessor_info an task durations.
% 
% Sinan Yildirim, 8.11.2016

% number of jobs
n = length(T);

% calculate the completion time recursively
if n == 1
    E = T(1);
else
    Pred_task = Predecessor_info{end};
    L = length(Pred_task);
    E_pred= zeros(1, L);
    for i = 1:L
        Last_task = Pred_task(i);
        E_pred(i) = PERT_completion_time(T(1:Last_task), Predecessor_info(1:Last_task));
    end
    E = max(E_pred) + T(end);
end