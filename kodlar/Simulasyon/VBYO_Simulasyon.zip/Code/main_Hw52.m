% main code for the Hw 5, Question 2
% 
% Sinan Yildirim, 18.10.2016
% 

clear all; close all; clc; fc = 0;

% parameters
a = 0.99; b = 1; var_x = 1; var_y = 4; var_x0 = 5;

% Generate the observations
n = 2000;
X = zeros(1, n);
X(1) = 0;
for t = 2:n
    X(t) = a*X(t-1) + randn*sqrt(var_x);
end
Y = b*X + randn(1, n)*sqrt(var_y);

%% SISR
% bootstrap proposal
prop_type = 1;
N = 100;
[X_samples1, W_norm1, mean_X_vec1] = SISR_Hw52(Y, a, b, var_x, var_y, var_x0, N, prop_type);
MSE1 = mean((mean_X_vec1 - X).^2);

N = 1000;
prop_type = 1;
[X_samples2, W_norm2, mean_X_vec2] = SISR_Hw52(Y, a, b, var_x, var_y, var_x0, N, prop_type);
MSE2 = mean((mean_X_vec2 - X).^2);

% optimum proposal
N = 100; 
prop_type = 2;
[X_samples3, W_norm3, mean_X_vec3] = SISR_Hw52(Y, a, b, var_x, var_y, var_x0, N, prop_type);
MSE3 = mean((mean_X_vec3 - X).^2);

fc = fc + 1; figure(fc);
subplot(3, 1,1);
plot(mean_X_vec1 - X);
title(sprintf('Bootstrap particle filter with N = 100: MSE = %.3f', MSE1));
subplot(3,1,2);
plot(mean_X_vec2 - X);
title(sprintf('Bootstrap particle filter with N = 1000: MSE = %.3f', MSE2));
subplot(3,1,3);
plot(mean_X_vec3 - X);
title(sprintf('Particle filter with optimum proposal N = 100: MSE = %.3f', MSE3));

fprintf('MSE with N = 100 and bootstrap proposal is %.3f \n', MSE1);
fprintf('MSE with N = 1000 and bootstrap proposal is %.3f \n', MSE2);
fprintf('MSE with N = 100 and optimum proposal is %.3f \n', MSE2);
