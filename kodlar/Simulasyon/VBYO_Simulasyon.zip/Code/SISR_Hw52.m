function [X_samples, W_norm, mean_X_vec] = SISR_Hw52(Y, a, b, var_x, var_y, var_x0, N, prop_type)

% [X_samples, W_norm] = SISR_Hw52(Y, a, b, var_x, var_y, var_x0, N, prop_type)
% 
% SISR (Particle filter) for the one dimentional linear Gaussian HMM
% 
% Sinan Yildirim, 18.12.2016

n = length(Y);
mean_X_vec = zeros(1, n);
% initialise

for t = 1:n
    if mod(t, 100) == 0
        disp(t);
    end
    
    if t == 1
        if prop_type == 1
            % generate N samples for X(1) from the importance density
            X_samples = sqrt(var_x0)*randn(1, N);
            % weight the particles
            log_w = -(Y(1) - b*X_samples).^2/(2*var_y) - 0.5*log(2*pi*var_y);
        else
            % since the weights will depend on the previous particles,
            % first calculate the weights
            pred_var_y = b^2*var_x0 + var_y;
            pred_mean_y = 0;
            log_w = -(Y(1) - pred_mean_y).^2/(2*pred_var_y) - 0.5*log(2*pi*pred_var_y);
            log_w = log_w*ones(1, N);
            
            % extend N samples using the importance density
            cond_var = 1/(1/var_x + b^2/var_y);
            cond_mean = cond_var*(b*Y(1)/var_y);
            X_samples = sqrt(cond_var)*randn(1, N) + cond_mean;    
        end
        
    else
        % resample:
        [res_ind] = resample(W_norm, 'multinomial');
        X_samples = X_samples(res_ind);
        
        if prop_type == 1 
            % bootstrap particle filter where the particles are proposed
            % from the transition density
            
            % extend N samples using the importance density
            X_samples = a*X_samples + sqrt(var_x)*randn(1, N);
            % calculate the incremental weights
            log_w = -0.5*(Y(t) - b*X_samples).^2/var_y - 0.5*log(2*pi*var_y);
        else
            % since the weights will depend on the previous particles,
            % first calculate the weights
            pred_var_y = b^2*var_x + var_y;
            pred_mean_y = b*a*X_samples;
            log_w = -0.5*(Y(t) - pred_mean_y).^2/pred_var_y - 0.5*log(2*pi*pred_var_y);
            
            % extend N samples using the importance density
            cond_var = 1/(1/var_x + b^2/var_y);
            cond_mean = cond_var*(a*X_samples/var_x + b*Y(t)/var_y);
            X_samples = sqrt(cond_var)*randn(1, N) + cond_mean;
        end
    end
    
    % normalise the weights
    W_norm = exp(log_w - log_sum(log_w));
    
    mean_X_vec(t) = X_samples*W_norm';
    
end