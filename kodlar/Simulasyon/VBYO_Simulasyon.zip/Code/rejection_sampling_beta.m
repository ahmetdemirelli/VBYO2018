function [X] = rejection_sampling_beta(a, b, size1, size2)

% [X] = rejection_sampling_beta(a, b, size1, size2)
%
% This function implemnets rejection sampling for Beta(a, b) and outputs
% random variates in a matrix of size size1 x size2
%
% For the proposal distribution, uniform distribution is used, so a < 1 or
% b < 1 are not allowed.
%
% Sinan Yildirim, 08.11.2016

if a < 1 || b < 1
    error('a < 1 or b < 1 are not permitted');
end


% If size is not specified, produce one sample
if nargin == 2
    size1 = 1;
    size2 = 1;
end
% If size is specified by a single number, assign the first dim. as 1
if nargin == 3
    size2 = size1;
    size1 = 1;
end

% if a = b = 1, we have the uniform distribution
if a == 1 && b == 1
    X = rand(size1, size2);
else
    % rejection sampling
    M = ((a-1)/(a + b - 2))^(a-1)*((b-1)/(a + b - 2))^(b-1);
    X = zeros(size1, size2);
    for i = 1:size1
        for j = 1:size2
            % method of inversion:
            accept = 0;
            while accept == 0
                % sample the proposed value
                x_prop = rand;

                u = rand;
                if u < x_prop^(a-1)*(1 - x_prop)^(b-1)/M
                    accept = 1;
                end
                % store the accepted value:
                X(i,j) = x_prop;
            end
        end
    end
end

