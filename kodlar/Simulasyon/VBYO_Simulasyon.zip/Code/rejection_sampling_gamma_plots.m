% rejection sampling for the Gamma distribution using exponential
% distribution as the instrumental distribution.
% 
% This code is used to generate Figure 2.3 of the main document.
% 
% Sinan Yildirim, 06.10.2016

clear all; clc; close all; fc = 0;
alpha = 2;

% x axis
x = 0.01:0.01:10;
% pdf of the gamma distribution at x
pdf_gamma = gampdf(x, alpha, 1);

lambda_opt = 1/alpha;
M_opt = alpha^alpha*exp(-alpha + 1)/gamma(alpha);

% pdf of the exponential distribution at x
pdf_exp = lambda_opt*exp(-lambda_opt*x);

% plot the densities:
fc = fc + 1; figure(fc);
subplot(1, 2, 1);
plot(x, pdf_gamma, 'b');
hold on;
plot(x, pdf_exp*M_opt, 'r');
plot(x, pdf_exp*1.5*M_opt, 'k');
hold off;
legend('p(x)', 'M^{\ast}q_{\lambda^{\ast}}(x)', 'Mq_{\lambda^{\ast}}(x) when M = 1.5 M^{\ast}');
xlabel('x');
title('rejection sampling for \Gamma(2, 1) with optimal choice for \lambda');


% plot for different lambda values, each with their optimum M:
lambda_vec = [lambda_opt 0.1 0.7];
L = length(lambda_vec);

% plot the densities:
subplot(1, 2, 2);
plot(x, pdf_gamma, 'b');
hold on;
color_mtx = {'k', 'r', 'g'};
s = {'p(x)'};
for i = 1:L
    lambda = lambda_vec(i);
    pdf_exp = lambda*exp(-lambda*x);
    M_lambda = ((alpha - 1)/(1 - lambda))^(alpha - 1)*exp(-alpha + 1)...
        /(lambda*gamma(alpha));
    plot(x, pdf_exp*M_lambda, 'color', color_mtx{i});
    s = [s, {sprintf('lambda = %.2f', lambda)}];
end
xlabel('x');
legend(s);
title('rejection sampling for \Gamma(2, 1) with different values of \lambda');