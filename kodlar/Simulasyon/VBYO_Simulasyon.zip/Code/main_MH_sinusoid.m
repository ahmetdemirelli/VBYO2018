% main code for exercise 5.5. of the main document
clear all; clc; close all; fc = 0;

% generate sinusoid data
% set the frequency, amplitude and the phase
w = 0.1;
a = 1;
z = pi;
n = 1000;
sigma_y = 1;

t = 1:n;
y = a*sin(w*t + z) + sigma_y*randn(1, n);
save('sinusoid_data', 'y');