function [X] = Gibbs_Poiss_chp(y, M, X_0, alpha, beta)

% [X] = Gibbs_Poiss_chp(y, M, X_0, alpha, beta)
% 
% This function runs the Gibbs sampling algorithm for the Poisson chagepoint
% model where the prior for the changepoint location is uniform and the
% priors for both regimes are Gamma(alpha, beta). The initial point is X0
% 
% Sinan Yildirim, 17.12.2016

n = length(y);

% these quantities will be used for sampling tau
cum_sum_y =  cumsum(y);
cum_sum_y_rev =  sum(y) - cum_sum_y;

tau = X_0(1);

% initialise
Tau = zeros(1, M);
Lambda_1 = zeros(1, M);
Lambda_2 = zeros(1, M);


for m = 1:M
    % sample lambda_1
    alpha_cond = sum(y(1:tau)) + alpha;
    beta_cond = beta + tau;
    lambda_1 = gamrnd(alpha_cond, 1/beta_cond);

    % sample lambda_2
    alpha_cond = sum(y(tau+1:n)) + alpha;
    beta_cond = beta + n - tau;
    lambda_2 = gamrnd(alpha_cond, 1/beta_cond);
    
    % sample tau
    % calculate the unnormalised log-probabilities
    log_cond_probs_tau = -(1:n)*lambda_1 + cum_sum_y*log(lambda_1)...
        -(n - (1:n))*lambda_2 + cum_sum_y_rev*log(lambda_2);
    % calculate the log of the normalising constant
    log_norm_const = log_sum(log_cond_probs_tau);
    % find the probabilities
    cond_probs_tau = exp(log_cond_probs_tau - log_norm_const);
    % sample tau using the calcualted probabilies
    tau = randsamp(cond_probs_tau);
    
    % store the samples
    Tau(m) = tau;
    Lambda_1(m) = lambda_1;
    Lambda_2(m) = lambda_2;
    
end

X = [Tau; Lambda_1; Lambda_2];
    
    
    
    
    
