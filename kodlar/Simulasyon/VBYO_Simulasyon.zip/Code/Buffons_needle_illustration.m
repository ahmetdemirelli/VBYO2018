% Buffon's needle experiment - illustration
% 
% This code generates Figures 1.1, 1.2, 1.3 and 1.4 of the main document
% 
% Sinan Yildirim, 28.09.2016
clear all; clc; close all; fc = 0;
N = 100;

table_width = 10;
% generate the (x, y) coordinates for the center of the needle
x_loc = table_width*rand(1, N);
y_loc = table_width*rand(1, N);
% generate the signed angle for the needle betweeen -pi/2 and pi/2 
theta_signed = pi*rand(1, N) - pi/2;

% (x, y) locations of the two ends of the needles
x_ends = [x_loc - sin(theta_signed)/2; x_loc + sin(theta_signed)/2];
y_ends = [y_loc - cos(theta_signed)/2; y_loc + cos(theta_signed)/2];

% the distance between the center of the needle and the closest line
d = abs(x_loc - round(x_loc));
% the acute angle
theta = abs(theta_signed);
% find the ones that cross a line
c = d < sin(theta)/2;
% estimate the probability
prob_cross_est = sum(c)/N;

% illustrate the needles on the table
fc = fc + 1; figure(fc);
% plot the lines on the table
plot([0:table_width;0:table_width], ...
    repmat([-1;table_width+1], 1, table_width+1), 'b');
hold on;
% plot the needles: the red ones are those who cross a line and the black
% ones are those who do not
plot(x_ends(:, c==1), y_ends(:, c==1), 'r');
plot(x_ends(:, c==0), y_ends(:, c==0), 'k');
hold off;
set(gca, 'xlim', [-1,11]);
set(gca, 'ylim', [-2,12]);

fc = fc + 1; figure(fc);
% view the results
scatter(theta(c == 1), d(c == 1), '.r');
hold on;
scatter(theta(c == 0), d(c == 0), '.k');
xlabel('\theta'); ylabel('d');
hold on; % this is to add the next plot to the already existing figure
x_axis = 0:0.01:pi/2;
plot(x_axis, sin(x_axis)/2, 'k');
hold off;
s1 = sprintf('Buffon''s needle, N = %d. The estimated prob is %.4f. ',...
    N, prob_cross_est);
s2 = sprintf('True value is %.4f', 2/pi);
title([s1 s2]);
