function X = randsamp(w, size1, size2)

% X = randsamp(w, size1, size2)
% 
% returns a sample from the distribution defined by positive weights in P.
% P is often a vector of probabilities but can be unnormalised.
%
% Last update time: 08.11.2016
% Written by: Sinan Yildirim

% If size is not specified, produce one sample
if nargin == 1
    size1 = 1;
    size2 = 1;
end
% If size is specified by a single number, assign the first dim. as 1
if nargin == 2
    size2 = size1;
    size1 = 1;
end

% if negative entry is found in w, report error
if min(w) < 0
    error('negative probabilities are not permitted!');
end

% normalize pmf if not and take the cumulative sum
w_cum = cumsum(w/sum(w));

X = zeros(size1, size2);
for i = 1:size1
    for j = 1:size2
        % method of inversion:
        u = rand;
        c = 1;
        while w_cum(c) < u 
            c = c+1;
        end
        X(i,j) = c;
    end
end