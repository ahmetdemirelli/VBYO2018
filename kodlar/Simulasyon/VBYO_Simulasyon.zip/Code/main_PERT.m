% This is the main code for the PERT example, Question 2 of Homework 2.
clear all; clc; close all; fc = 0;

% The predecessor structure and mean durations of tasks
Predecessor_info = {[], 1, 1, 2, 2, 3, 3, 3, [5, 6, 7], [4, 8, 9]};
mean_dur_time = [4 4 2 5 2 3 2 3 2 2];

%% Second part of Question 2 of Homework 2
% generate the mean duration times:
T = exprnd(mean_dur_time);

% compare the two algorithms, one is general and the other is specific to
% the given in Table 3.1.
% The general one is done using recursive coding, i.e. using the same
% function inside the definition of the function.
[E_1] = PERT_completion_time_specific_to_table_3_1(T);
[E_2] = PERT_completion_time(T, Predecessor_info);
disp([E_1, E_2]);

%% Third part of Question 2 of Homework 2
N = 10000;
T = exprnd(repmat(mean_dur_time, N, 1));
E = PERT_completion_time_specific_to_table_3_1(T);

fc = fc + 1; figure(fc);
hist(E, 50);
xlabel('completion times');
ylabel('frequency');
title('histogram of completion times: 50 bins');

% estimate for the mean completion time
mean_E_Monte_Carlo = mean(E);
fprintf('mean completion time estimate is %.5f \n', mean_E_Monte_Carlo);


%% Fourth part of Question 2 of Homework 2
M = 1000;
N = 10000;
mean_phi_MC = zeros(1, M);

for m = 1:M
    if mod(m, 100)== 0
        disp(m);
    end
    T = exprnd(repmat(mean_dur_time, N, 1));
    E = PERT_completion_time_specific_to_table_3_1(T);
    
    % phi(T) = I(E > 70);
    % Monte Carlo estimate of probability of E > 70
    mean_phi_MC(m) = mean(E > 70); 
end
sample_mean = mean(mean_phi_MC);
sample_std = std(mean_phi_MC);
fprintf('10^6 times the sample mean of the MC estimates of phi is %.8f \n',...
    10^6*sample_mean);
fprintf('10^5 times the sample std of the MC estimates is %.8f \n',...
    10^5*sample_std);

%% Fifth part of Question 2 of Homework 2
kappa = 2;
mean_dur_time_prop = kappa*mean_dur_time;

M = 1000;
N = 10000;
mean_phi_MC = zeros(1, M);

for m = 1:M
    if mod(m, 100)== 0
        disp(m);
    end
    % sample task times from the proposal distribution
    T = exprnd(repmat(mean_dur_time_prop, N, 1));
    % compute the importance sampling wieghts
    W = prod(mean_dur_time_prop./mean_dur_time)...
        *exp(T*(1./mean_dur_time_prop - 1./mean_dur_time)');
    E = PERT_completion_time_specific_to_table_3_1(T);
    mean_phi_MC(m) = mean((E > 70).*W);
    
end

sample_mean = mean(mean_phi_MC);
sample_std = std(mean_phi_MC);
fprintf('10^6 times the sample mean of the IS estimates of phi is %.8f \n',...
    10^6*sample_mean);
fprintf('10^5 times the sample std of the MC estimates is %.8f \n',...
    10^5*sample_std);
