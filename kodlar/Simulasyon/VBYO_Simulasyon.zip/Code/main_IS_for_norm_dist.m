% This is the main code for Question 1 of Hw 2

% number of Monte Carlo trials
M = 10000;

% number of samples for each
N = 100;

% variance of the distribution
sigma = 1;

% select k
k = 1/2;

Est_x_MC = zeros(1, M);
Est_x_IS = zeros(1, M);
Est_x2_MC = zeros(1, M);
Est_x2_IS = zeros(1, M);

for m = 1:M
    
    % Plug-in Monte Carlo
    X_samp_MC = sigma*randn(1, N);
    % Compute the estimators:
    Est_x_MC(m) = mean(X_samp_MC);
    Est_x2_MC(m) = mean(X_samp_MC.^2);
    
    %  IS sampling:
    % sample from Q
    X_samp_IS = sigma*randn(1, N)/sqrt(k);
    % calculate the weights
    log_W_IS = -0.5*(log(k) + X_samp_IS.^2*(1/sigma^2 - k/sigma^2));
    % Compute the estimators
    Est_x_IS(m) = mean(exp(log_W_IS + log(X_samp_IS)));
    Est_x2_IS(m) = mean(exp(log_W_IS + 2*log(X_samp_IS)));

end

%
fprintf('Variance of MC for x is %.5f \n', var(Est_x_MC));
fprintf('Variance of IS for x is %.5f \n', var(Est_x_IS));
fprintf('Variance of MC for x^2 is %.5f \n', var(Est_x2_MC));
fprintf('Variance of IS for x^2 is %.5f \n', var(Est_x2_IS));