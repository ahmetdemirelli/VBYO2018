function r = sample_gauss(mu, cov, N)

% r = sample_gauss(mu, cov, N)
%
% Samples N Gaussian vectors from the multivariate Gaussian distribution with
% mean mu and covariance matrix cov. 
%
% Last update time: 09.08.2009
% Written by: Sinan Yildirim

C = cholcov(cov)';
x = randn(size(C, 2),N);
r = C*x + mu(:, ones(1, N));